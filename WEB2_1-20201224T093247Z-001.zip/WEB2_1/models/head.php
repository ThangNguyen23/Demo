<meta charset="UTF-8">
<meta name="description" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<!-- The above 4 meta tags *must* come first in the head; any other head content must come *after* these tags -->

<!-- Title  -->
<title>Giày xấu giá cao </title>

<!-- Favicon  -->
<link rel="icon" href="img/core-img/favicon.ico">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css">

<link rel="stylesheet" href="./css/aos.css">
<!-- Core Style CSS -->
<link rel="stylesheet" href="css/style1.css">
<link rel="stylesheet" href="style.css">
<!-- jQuery (Necessary for All JavaScript Plugins) -->
<script src="js/jquery/jquery-2.2.4.min.js"></script>
<script src="js/bootstrap-notify.min.js"></script>
<script src="js/bootstrap-input-spinner.js"></script>

<script src="./js/sweetalert2.min.js"></script>
<link rel="stylesheet" href="./css/sweetalert2.min.css">

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/pikaday/1.6.1/css/pikaday.min.css">
