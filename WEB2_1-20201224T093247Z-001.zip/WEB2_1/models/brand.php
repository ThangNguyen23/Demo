<div class="brands-area d-flex align-items-center justify-content-between">
    <!-- Brand Logo -->
    <div class="single-brands-logo" data-aos="zoom-in-up" data-aos-delay="200" data-aos-once="true">
        <img src="./img/core-img/nike.jpg" alt="">
    </div>
    <!-- Brand Logo -->
    <div class="single-brands-logo" data-aos="zoom-in-up" data-aos-delay="400" data-aos-once="true">
        <img src="./img/core-img/adidas.jpg" alt="">
    </div>
    <!-- Brand Logo -->
    <div class="single-brands-logo" data-aos="zoom-in-up" data-aos-delay="600" data-aos-once="true">
        <img src="./img/core-img/ro.jpg" alt="">
    </div>
    <!-- Brand Logo -->
    <div class="single-brands-logo" data-aos="zoom-in-up" data-aos-delay="800" data-aos-once="true">
        <img src="./img/core-img/maxnco.jpg" alt="">
    </div>
    <div class="single-brands-logo" data-aos="zoom-in-up" data-aos-delay="1000" data-aos-once="true">
        <img src="./img/core-img/puma.jpg" alt="">
    </div>
</div>
