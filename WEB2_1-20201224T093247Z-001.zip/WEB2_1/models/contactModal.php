<div class="contact-area d-flex align-items-center">

        <div class="google-map">
            <div id="googleMap"></div>
        </div>

        <div class="contact-info">
            <h2>Thông tin Liên Hệ</h2>
            <p>M2N luôn phấn đấu, nỗ lực không ngừng để đem lại cho người tiêu dùng những sản phẩm công nghệ tiên tiến, và đã trở thành một trong những thương hiệu đáng tin cậy và được yêu thích nhất. M2N luôn cam kết cung cấp hàng chính hãng từ các nhà sản xuất, chất lượng luôn được đảm bảo và mức giá phù hợp trong môi trường cạnh tranh.</p>

            <div class="contact-address mt-50">
                <p><span>địa chỉ:</span> 273 An Dương Vương, Phường 3, Quận 5, TP.HCM</p>
                <p><span>điện thoại:</span> (028) 38382 664</p>
                <p>vpkcntt@sgu.edu.vn</p>
            </div>
        </div>

    </div>