-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2020 at 05:39 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `web2_1`
--

-- --------------------------------------------------------

--
-- Table structure for table `authentication`
--

CREATE TABLE `authentication` (
  `authenID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `authenRole` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `authentication`
--

INSERT INTO `authentication` (`authenID`, `authenRole`) VALUES
('0', 'Admin'),
('1', 'Sale'),
('2', 'User');

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `billID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `billPurchaser` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `billDate` datetime NOT NULL,
  `billDelivery` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `billTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `brand`
--

CREATE TABLE `brand` (
  `brandID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `brandName` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `brand`
--

INSERT INTO `brand` (`brandID`, `brandName`) VALUES
('006', 'Nike'),
('007', 'Adidas'),
('008', 'Rick Owens'),
('009', 'Max n Co '),
('010', 'Annas');

-- --------------------------------------------------------

--
-- Table structure for table `cetorgry`
--

CREATE TABLE `cetorgry` (
  `cetorgryID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `cetorgryName` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cetorgry`
--

INSERT INTO `cetorgry` (`cetorgryID`, `cetorgryName`) VALUES
('001', 'Giày nam'),
('002', 'Giày nữ'),
('003', 'Giày thể thao');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `userID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `firstName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`userID`, `firstName`, `lastName`, `email`) VALUES
('0010', 'Nguyen Van', 'Rung', 'galatasaray@gmail.com'),
('0011', 'Nguyên ', 'Ngọc', 'doctorsuperhero13@gmail.com'),
('0012', 'Nguyên', 'Anh', 'gaga@gmail.com'),
('0013', 'Nguyễn Văn', 'Rớt', 'sale@gmail.com'),
('0014', 'Nguyễn Đức Nguyên ', 'Ngọc', 'ngoc.nguyenducnguyen@gmail.com'),
('0015', 'Nguyễn Đức Nguyên ', 'Ngọc', 'ngoc.nguyenducnguyen1@gmail.com'),
('0016', 'Nguyễn Đức Nguyên ', 'Ngọc', 'admimnnn@gmail.com'),
('0017', 'Nguyễn Đức Nguyên', 'Ngọc', 'asdss@gmail.com'),
('0018', 'Nguyễn Đức Nguyên', 'Ngọc', 'mmm@gmail.com'),
('0019', 'Nguyễn Đức Nguyên', 'Ngọc', 'abcsss@gmail.com'),
('002', 'Nguyễn Văn', 'Thỏ', 'thanos1234@gmail.com'),
('0020', 'Nguyen', 'Anh', 'na223@gmail.com'),
('0021', 'Nguyen', 'Anh', 'na2232@gmail.com'),
('0022', 'lê văn', 'vũ', 'lvv1231@gmail.com'),
('0023', 'Phan Hửu ', 'Nghĩa', 'phn12312@gmail.com'),
('0024', 'Ngoc', 'Nguyen', 'sale2@gmail.com'),
('0025', 'nguyễn văn', 'rớt', 'abc11312@gmail.com'),
('003', 'Nguyễn Đức Nguyên', 'Ngọc', 'ngoc.nguyenducng@gmail.com'),
('005', 'Nguyễn Văn ', 'ABC', 'sale123@gmail.com'),
('008', 'Mai', 'Tram', 'maitram@gmail.com'),
('009', 'Trương', 'Tam Phong', '3wind@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `productName` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `productDescription` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `productPrice` int(11) NOT NULL,
  `productAmount` int(11) NOT NULL,
  `productCetorgry` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `productBrand` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `IMG` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `productName`, `productDescription`, `productPrice`, `productAmount`, `productCetorgry`, `productBrand`, `IMG`, `state`) VALUES
('001', 'Air Jordan 11', 'ANB%acasaaadasdasdsadasdasdasdasdasdasdasdasd', 8900000, 50, '003', '006', '001.jpg', 1),
('002', 'Max n Co', 'ANB%acas', 449000, 50, '002', '009', '002.jpg', 0),
('003', 'Annas N003', 'ANB%acas', 439000, 50, '001', '010', '003.jpg', 1),
('004', 'Max n Co M004', 'ANB%acas', 1390000, 50, '002', '009', '004.jpg', 1),
('005', 'Max n Co Casual shoes', 'ANB%acas', 380000, 50, '002', '009', '005.jpg', 1),
('006', 'Annas N006', 'ANB%acas', 2590000, 50, '001', '010', '006.jpg', 1),
('007', 'Annas N007', 'ANB%acas', 1405000, 50, '001', '010', '007.jpg', 1),
('008', 'Max n Co MC008', '', 315000, 50, '002', '009', '008.jpg', 1),
('009', 'Nike LeBron 11 EXT SUEDE', '', 5190000, 50, '003', '006', '009.jpg', 1),
('010', 'Max n Co Slippers ', '', 1990000, 50, '002', '009', '010.jpg', 1),
('011', 'Adidas Yeezy Oxford', '', 30000000, 50, '003', '007', '011.jpg', 1),
('012', 'Max n Co high heels', '', 2500000, 50, '002', '009', '012.jpg', 1),
('013', 'Annas N013', '', 3390000, 50, '001', '010', '013.jpg', 1),
('014', 'Annas High Heels N014', '', 2000000, 50, '002', '010', '014.jpg', 1),
('015', 'Annas N015', '', 2090000, 50, '001', '010', '015.jpg', 1),
('016', 'Annas N016', '', 1950000, 50, '002', '010', '016.jpg', 1),
('017', 'Annas N017 ', '', 4490000, 50, '002', '010', '017.jpg', 1),
('018', 'Annas N018', '', 3890000, 50, '002', '010', '018.jpg', 1),
('019', 'Annas N019', '', 3890000, 50, '001', '010', '019.jpg', 1),
('020', 'Annas SN020', '', 1390000, 50, '001', '010', '020.jpg', 1),
('021', 'Annas N021', '', 3350000, 50, '001', '010', '021.jpg', 1),
('022', 'Annas SN022', '', 2990000, 50, '001', '010', '022.jpg', 1),
('023', 'Annas N023', '', 3390000, 50, '002', '010', '023.jpg', 1),
('024', 'Max n Co MC024', '', 2390000, 50, '002', '009', '024.jpg', 1),
('025', 'Max n Co Red Velvet', '', 8790000, 50, '002', '009', '025.jpg', 1),
('026', 'Max n Co N026', '', 1990000, 50, '002', '009', '026.jpg', 1),
('027', 'Annas N027', '', 3880000, 50, '002', '010', '027.jpg', 1),
('028', 'Annas N028', '', 1590000, 50, '002', '010', '028.jpg', 1),
('029', 'Annas N029', '', 990000, 50, '001', '010', '029.jpg', 1),
('030', 'Annas N030', '', 1950000, 50, '001', '010', '030.jpg', 1),
('031', 'Annas N031', '', 1450000, 50, '001', '010', '031.jpg', 1),
('032', 'Annas N032', '', 1390000, 50, '001', '010', '032.jpg', 1),
('033', 'Annas N033', '', 2390000, 50, '001', '010', '033.jpg', 1),
('034', 'Annas N034', '', 3790000, 50, '001', '010', '034.jpg', 1),
('035', 'Max n Co N035', '', 1000000, 50, '002', '009', '035.jpg', 1),
('036', 'Annas N036', '', 2000000, 50, '002', '010', '036.jpg', 1),
('037', 'Max n Co M037', '', 2350000, 50, '002', '009', '037.jpg', 1),
('038', 'Max n Co M038', '', 1590000, 50, '002', '009', '038.jpg', 1),
('039', 'Max n Co M039', '', 2790000, 50, '002', '009', '039.jpg', 1),
('ADI_001', 'Adidas YEEZY BELUGA', '', 15000000, 10, '003', '007', 'ADI_001.png', 1),
('AJ_001', 'Air Jordan 4 Retro Cactus Jack', '', 6800000, 10, '003', '006', 'AJ_001.jpg', 1),
('AJ_004', 'Air Jordan 3 Retro Edition', '', 5500000, 12, '003', '006', 'AJ_004.png', 1),
('AJ_005', 'Air Jordan 1', '', 5500000, 12, '003', '006', 'AJ_005.png', 1),
('NK_001', 'Nike Air Force 1 High 2017', '', 3500000, 20, '003', '006', 'NK_001.jpg', 1),
('RO_001', 'Rick Owens High', '', 8600000, 5, '003', '008', 'RO_001.png', 1),
('RO_002', 'Rick Owens Low', '', 8500000, 20, '003', '008', 'RO_002.png', 1),
('RO_003', 'Rick Owens GEO BASKET', '', 11000000, 5, '003', '008', 'RO_003.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `receipt`
--

CREATE TABLE `receipt` (
  `receiptID` int(11) NOT NULL,
  `userName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `firstName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `lastName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `country` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `address` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `receiptTotal` int(11) NOT NULL,
  `receiptDate` datetime NOT NULL,
  `status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `receipt`
--

INSERT INTO `receipt` (`receiptID`, `userName`, `firstName`, `lastName`, `country`, `address`, `phone`, `email`, `description`, `receiptTotal`, `receiptDate`, `status`) VALUES
(1, 'admin', 'Nguyễn Văn', 'Tho', 'TP.Hồ Chí Minh', '224', '0121121121', 'minhdatsg2000@gmail.com', 'aaa', 2975000, '2020-05-31 09:15:28', 1),
(2, 'admin', 'Nguyễn Văn', 'Tho', 'TP.Hồ Chí Minh', '242', '0121121212', 'minhdatsg2000@gmail.com', '', 15130000, '2020-05-31 09:16:08', 1),
(3, 'admin', 'Nguyễn Văn', 'Tho', 'TP.Hồ Chí Minh', '242', '0933926175', 'minhdatsg2000@gmail.com', '', 7310000, '2020-05-31 09:16:42', 1),
(4, 'admin', 'Nguyên ', 'Ngọc', 'TP.Hồ Chí Minh', '429 Bà Hạt P4 Q10', '0933926175', 'ngoc.nguyenducnguyen@gmail.com', 'giao giờ hành chính', 7471500, '2020-05-31 18:58:09', 1),
(5, 'admin', 'Nguyễn Văn', 'Tho', 'TP.Hồ Chí Minh', '123', '0123456789', 'minhdatsg2000@gmail.com', '', 2371500, '2020-05-31 19:29:36', 1),
(6, 'Saler', 'Trương', 'Tam Phong', 'TP.Hồ Chí Minh', '242/60 ', '0121133567', 'sale1@gmail.com', '', 3306500, '2020-05-31 19:45:27', 1),
(7, 'na2243', 'Nguyen', 'Anh', 'TP.Hồ Chí Minh', '429 Bà Hạt', '166523215', 'na2232@gmail.com', '', 5780000, '2020-06-01 17:21:56', 1),
(8, 'lvv11212', 'lê văn', 'vũ', 'TP.Hồ Chí Minh', '53 NTMK', '0156445123', 'lvv1231@gmail.com', '', 7225000, '2020-06-02 19:58:03', 1),
(9, 'admin', 'Nguyễn Văn', 'Tho', 'TP.Hồ Chí Minh', '429 Bà Hạt', '02838345916', 'minhdatsg2000@gmail.com', '', 8925000, '2020-06-03 17:47:45', 1),
(10, 'admin', 'Nguyễn Đức', 'Ngọc', 'TP.Hồ Chí Minh', '429 Bà Hạt P4 Q10', '933926167', 'ngoc.nguyenducng@gmail.com', '', 3306500, '2020-06-04 07:30:15', 1),
(11, 'admin', 'Nguyễn Đức', 'Ngọc', 'TP.Hồ Chí Minh', '429 BaHat', '03838345916', 'ngoc.nguyenducng@gmail.com', '', 9350000, '2020-06-04 08:19:37', 1),
(12, 'admin', 'Nguyễn Đức', 'Ngọc', 'TP.Hồ Chí Minh', '1121', '0123456789', 'ngoc.nguyenducng@gmail.com', '', 132260000, '2020-06-06 16:27:39', 1),
(13, 'admin', 'Nguyễn Đức', 'Ngọc', 'TP.Hồ Chí Minh', '429 Bà Hạt P4 Q10', '0121456789', 'ngoc.nguyenducng@gmail.com', '', 2975000, '2020-06-07 17:29:59', 1);

--
-- Triggers `receipt`
--
DELIMITER $$
CREATE TRIGGER `DeleteReceipt` BEFORE DELETE ON `receipt` FOR EACH ROW DELETE FROM receiptdetail WHERE receiptdetail.receiptID = OLD.receiptID
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `receiptdetail`
--

CREATE TABLE `receiptdetail` (
  `receiptID` int(11) NOT NULL,
  `productID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `productName` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `quality` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `receiptdetail`
--

INSERT INTO `receiptdetail` (`receiptID`, `productID`, `productName`, `quality`, `price`, `total`) VALUES
(1, 'NK_001', 'Nike Air Force 1 High 2017', 1, 3500000, 3500000),
(2, '001', 'Air Jordan 11', 2, 8900000, 17800000),
(3, 'RO_001', 'Rick Owens High', 1, 8600000, 8600000),
(4, '025', 'Max n Co Red Velvet', 1, 8790000, 8790000),
(5, '039', 'Max n Co M039', 1, 2790000, 2790000),
(6, '019', 'Annas N019', 1, 3890000, 3890000),
(7, 'AJ_001', 'Air Jordan 4 Retro Cactus Jack', 1, 6800000, 6800000),
(8, 'RO_002', 'Rick Owens Low', 1, 8500000, 8500000),
(9, 'NK_001', 'Nike Air Force 1 High 2017', 3, 3500000, 10500000),
(10, '018', 'Annas N018', 1, 3890000, 3890000),
(11, 'AJ_005', 'Air Jordan 1', 2, 5500000, 11000000),
(12, '018', 'Annas N018', 40, 3890000, 155600000),
(13, 'NK_001', 'Nike Air Force 1 High 2017', 1, 3500000, 3500000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userID` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `userName` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `userPass` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `userAuthentication` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `state` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userID`, `userName`, `userPass`, `userAuthentication`, `state`) VALUES
('003', 'admin', '$2y$10$cbK86YxpsT0sRgmtrY4ca.BRh2v.wzQ3oyX8EtxRPqgzFFz6xn/xm', '0', 1),
('0022', 'lvv11212', '$2y$10$DW6RHvg/MsfoKW1523LZbeF59ZoOdVydBasgiRTI6lhqSF5MgeDcq', '2', 1),
('008', 'maitram', '$2y$10$d3tdkpL.Mosoy4NXlb3RiuyPidMrIZtrNaJAKyOFjfU5L4yu05LmG', '2', 1),
('0021', 'na2243', '$2y$10$Afp0QcDT/Fxmp1rBUjC6OOBNDR5KijfvJNUHDqi0bPluOzsIxB1nK', '2', 1),
('0012', 'nana123', '$2y$10$zoyQnEx6CBh6MXdfHVRDu.9MVYyg3GnTnhyOW5eWqmfeq9FAbyYre', '2', 1),
('0020', 'nana223', '$2y$10$bIJGrYunrxpANa2M2IgM5egOf4yNLInkODO6IZpnU9wQcEAc6E72a', '2', 1),
('0011', 'nguyenngoc', '$2y$10$lLfpVlcF9pfBy6850sIVyuTe7JMYtXPno5RsvOb4xkLcLRNeRwZK.', '0', 1),
('0010', 'nintendo12', '$2y$10$cbK86YxpsT0sRgmtrY4ca.BRh2v.wzQ3oyX8EtxRPqgzFFz6xn/xm', '2', 1),
('0023', 'phn1231', '$2y$10$qJf6yEpkGsraNOoD72MsV.zQjbbSWgyIAfs3RvFCzebZ75RU9kuam', '2', 1),
('0013', 'sale1', '$2y$10$.LC0V7DnSkIyMtoGymi4SuO3.A1k5RqFLHusd8maTT9oNiE5A/aD2', '1', 1),
('0024', 'sale2', '$2y$10$pq82YrMP.HTLgjMI3xXLA.Aj.AB4CIK7caRlH/9xiSV9KAOpG3KsS', '1', 1),
('005', 'Saler', '$2y$10$lHg0ItOfCeGXzcfnxkKTZuAvBV0o1/js3m.E8XtlglPfA7rSkJYza', '1', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `authentication`
--
ALTER TABLE `authentication`
  ADD PRIMARY KEY (`authenID`);

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`billID`),
  ADD KEY `billPurchaser` (`billPurchaser`);

--
-- Indexes for table `brand`
--
ALTER TABLE `brand`
  ADD PRIMARY KEY (`brandID`);

--
-- Indexes for table `cetorgry`
--
ALTER TABLE `cetorgry`
  ADD PRIMARY KEY (`cetorgryID`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`),
  ADD KEY `FK_Brand` (`productBrand`) USING BTREE,
  ADD KEY `FK_Cetogry` (`productCetorgry`) USING BTREE;

--
-- Indexes for table `receipt`
--
ALTER TABLE `receipt`
  ADD PRIMARY KEY (`receiptID`),
  ADD KEY `userName` (`userName`),
  ADD KEY `userName_2` (`userName`),
  ADD KEY `receiptDate` (`receiptDate`);

--
-- Indexes for table `receiptdetail`
--
ALTER TABLE `receiptdetail`
  ADD PRIMARY KEY (`receiptID`,`productID`) USING BTREE,
  ADD KEY `receiptID` (`receiptID`),
  ADD KEY `productID` (`productID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userName`) USING BTREE,
  ADD KEY `userAuthentication` (`userAuthentication`),
  ADD KEY `userID` (`userID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`productBrand`) REFERENCES `brand` (`brandID`),
  ADD CONSTRAINT `product_ibfk_2` FOREIGN KEY (`productCetorgry`) REFERENCES `cetorgry` (`cetorgryID`);

--
-- Constraints for table `receipt`
--
ALTER TABLE `receipt`
  ADD CONSTRAINT `receipt_ibfk_1` FOREIGN KEY (`userName`) REFERENCES `user` (`userName`);

--
-- Constraints for table `receiptdetail`
--
ALTER TABLE `receiptdetail`
  ADD CONSTRAINT `receiptdetail_ibfk_1` FOREIGN KEY (`receiptID`) REFERENCES `receipt` (`receiptID`),
  ADD CONSTRAINT `receiptdetail_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `product` (`productID`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`userAuthentication`) REFERENCES `authentication` (`authenID`),
  ADD CONSTRAINT `user_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `customer` (`userID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
